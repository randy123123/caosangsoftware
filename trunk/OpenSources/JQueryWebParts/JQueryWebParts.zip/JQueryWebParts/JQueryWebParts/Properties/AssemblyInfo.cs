﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Web.UI;
using System.Resources;
using System.Security;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Tonii.JQueryWebParts")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("JQueryWebParts")]
[assembly: AssemblyCopyright("Copyright Antoine Dongois © 2010")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("790617b0-4dec-43c5-ae58-5d2833a5b4ad")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers 
// by using the '*' as shown below:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AllowPartiallyTrustedCallers()]

/**
 *  embedded resources
 */

// images
[assembly: NeutralResourcesLanguage("en-US")]
[assembly: WebResource("Tonii.JQueryWebParts.Resources.img.deltab.png", "images/png")]
[assembly: WebResource("Tonii.JQueryWebParts.Resources.img.addtab.png", "images/png")]
[assembly: WebResource("Tonii.JQueryWebParts.Resources.img.addwebparts.png", "images/png")]
[assembly: WebResource("Tonii.JQueryWebParts.Resources.img.delwebparts.png", "images/png")]
// jquery
[assembly: WebResource("Tonii.JQueryWebParts.Resources.js.jquery-1.4.2.min.js", "text/javascript")]
[assembly: WebResource("Tonii.JQueryWebParts.Resources.js.jquery-ui-1.8.2.custom.min.js", "text/javascript")]
[assembly: WebResource("Tonii.JQueryWebParts.Resources.js.jquery.cookie.js", "text/javascript")]

// smoothness theme for jquery-ui
[assembly: WebResource("Tonii.JQueryWebParts.Resources.themes.smoothness.jquery-ui-1.8.2.custom.css", "text/css", PerformSubstitution=true)]
[assembly: WebResource("Tonii.JQueryWebParts.Resources.themes.smoothness.images.ui-anim_basic_16x16.gif", "images/gif")]
[assembly: WebResource("Tonii.JQueryWebParts.Resources.themes.smoothness.images.ui-bg_flat_0_aaaaaa_40x100.png", "images/png")]
[assembly: WebResource("Tonii.JQueryWebParts.Resources.themes.smoothness.images.ui-bg_flat_75_ffffff_40x100.png", "images/png")]
[assembly: WebResource("Tonii.JQueryWebParts.Resources.themes.smoothness.images.ui-bg_glass_55_fbf9ee_1x400.png", "images/png")]
[assembly: WebResource("Tonii.JQueryWebParts.Resources.themes.smoothness.images.ui-bg_glass_65_ffffff_1x400.png", "images/png")]
[assembly: WebResource("Tonii.JQueryWebParts.Resources.themes.smoothness.images.ui-bg_glass_75_dadada_1x400.png", "images/png")]
[assembly: WebResource("Tonii.JQueryWebParts.Resources.themes.smoothness.images.ui-bg_glass_75_e6e6e6_1x400.png", "images/png")]
[assembly: WebResource("Tonii.JQueryWebParts.Resources.themes.smoothness.images.ui-bg_glass_95_fef1ec_1x400.png", "images/png")]
[assembly: WebResource("Tonii.JQueryWebParts.Resources.themes.smoothness.images.ui-bg_highlight-soft_75_cccccc_1x100.png", "images/png")]
[assembly: WebResource("Tonii.JQueryWebParts.Resources.themes.smoothness.images.ui-icons_222222_256x240.png", "images/png")]
[assembly: WebResource("Tonii.JQueryWebParts.Resources.themes.smoothness.images.ui-icons_2e83ff_256x240.png", "images/png")]
[assembly: WebResource("Tonii.JQueryWebParts.Resources.themes.smoothness.images.ui-icons_454545_256x240.png", "images/png")]
[assembly: WebResource("Tonii.JQueryWebParts.Resources.themes.smoothness.images.ui-icons_888888_256x240.png", "images/png")]
[assembly: WebResource("Tonii.JQueryWebParts.Resources.themes.smoothness.images.ui-icons_cd0a0a_256x240.png", "images/png")]
