using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Utilities;
using System.Collections;
using System.Collections.ObjectModel;
using System.Globalization;


namespace Tonii.JQueryWebParts.WebControls
{
    [ToolboxData("<{0}:JQueryTabsWebPart runat=\"server\"></{0}:JQueryTabsWebPart>")]
    public class JQueryTabsWebPart : WebPart
    {
        #region Events
        public event EventHandler<TabEventArgs> TabAdded;
        public event EventHandler<TabEventArgs> TabDeleted;
        #endregion

        #region Fields
        private Dictionary<KeyValuePair<string, string>, List<string>> webpartsPerTab = new Dictionary<KeyValuePair<string, string>, List<string>>();
        protected Dictionary<string, ImageButton> deleteButtons = new Dictionary<string, ImageButton>();
        private ImageButton btnAddTab;
        private string tabsConstructorTemplate = "";
        private bool includeJQueryLibraries = true;
        private bool useDefaultTheme = true;
        #endregion

        #region Properties
        [Personalizable(PersonalizationScope.Shared)]
        [WebBrowsable(false)]
        public bool IncludeJQueryLibraries
        {
            get { return this.includeJQueryLibraries; }
            set { this.includeJQueryLibraries = value; }
        }
        
        [Personalizable(PersonalizationScope.Shared)]
        [WebBrowsable(false)]
        public bool UseDefaultTheme
        {
            get { return this.useDefaultTheme; }
            set { this.useDefaultTheme = value; }
        }

        [Personalizable(PersonalizationScope.Shared)]
        [WebBrowsable(false)]
        public string TabsConstructorTemplate
        {
            get { return this.tabsConstructorTemplate; }
            set { this.tabsConstructorTemplate = value; }
        }

        [Personalizable(PersonalizationScope.Shared)]
        [WebBrowsable(false)]
        public Dictionary<KeyValuePair<string, string>, List<string>> WebPartsPerTab
        {
            get { return webpartsPerTab; }
            set { webpartsPerTab = value; }
        }

        protected string TabsId
        {
            get{
            return this.ClientID + "_tabs";
            }
        }

        #endregion

        #region Constructors
        public JQueryTabsWebPart()
        {
        }
        #endregion

        #region Static Methods
        protected static string ListToJSArray(List<string> elements)
        {
            StringBuilder jsArray = new StringBuilder("[");
            for (int i = 0; i < elements.Count; i++)
            {
                string s = elements[i];
                jsArray.AppendFormat("\"{0}\"", s);
                if (i != elements.Count - 1)
                    jsArray.Append(",");

            }
            jsArray.Append("]");
            return jsArray.ToString();
        }
        #endregion

        #region Methods

        protected override void CreateChildControls()
        {
            base.CreateChildControls();
            btnAddTab = new ImageButton();
            btnAddTab.ImageUrl = Page.ClientScript.GetWebResourceUrl(typeof(JQueryTabsWebPart), "Tonii.JQueryWebParts.Resources.img.addtab.png");
            btnAddTab.Click += new ImageClickEventHandler(btnAddTab_Click);
            btnAddTab.ToolTip = "New tab";
            this.Controls.Add(btnAddTab);
            this.PreRender += new EventHandler(JQueryTabsWebPart_PreRender);
            foreach(KeyValuePair<string, string> kvp in this.WebPartsPerTab.Keys)
            {
                AddTabDeleteButton(kvp.Key);
            }
        }

        protected void AddTabDeleteButton(string tabId)
        {
            ImageButton btnDelete = new ImageButton();
            btnDelete.Style[HtmlTextWriterStyle.Padding] = "5px";
            btnDelete.ImageAlign = ImageAlign.Middle;
            btnDelete.ImageUrl = Page.ClientScript.GetWebResourceUrl(typeof(JQueryTabsWebPart), "Tonii.JQueryWebParts.Resources.img.deltab.png");
            btnDelete.ID = tabId;
            btnDelete.ToolTip = "Delete this tab";
            btnDelete.CommandArgument = tabId;
            btnDelete.Command += new CommandEventHandler(btnDelete_Command);
            this.Controls.Add(btnDelete);
            deleteButtons.Add(btnDelete.ID, btnDelete);
        }

        private KeyValuePair<string, string>? FindTabById(string tabId)
        {
            foreach (KeyValuePair<string, string> kvp in this.WebPartsPerTab.Keys)
            {
                if (kvp.Key == tabId)
                    return kvp;
            }
            return null;
        }

        private void SetEditModeControlsVisibility()
        {
            if (this.WebPartManager.DisplayMode == WebPartManager.BrowseDisplayMode)
            {
                btnAddTab.Visible = false;
                foreach (ImageButton btn in deleteButtons.Values)
                {
                    btn.Visible = false;
                }
            }
            else {
                btnAddTab.Visible = true;
                foreach (ImageButton btn in deleteButtons.Values)
                {
                    btn.Visible = true;
                }
            }
        }

        public override EditorPartCollection CreateEditorParts()
        {
            List<EditorPart> editorParts = new List<EditorPart>();
            JQueryTabsEditorPart jqtep = new JQueryTabsEditorPart();
            jqtep.ID = "jqtep";
            jqtep.Title = "Tabs";
            editorParts.Add(jqtep);
            return new EditorPartCollection(editorParts); 
        }

        protected void IncludeJQueryLibrariesScripts()
        {
            HtmlGenericControl jQueryInclude = new HtmlGenericControl("script");
            jQueryInclude.Attributes.Add("type", "text/javascript");
            jQueryInclude.Attributes.Add("src", Page.ClientScript.GetWebResourceUrl(
                typeof(JQueryTabsWebPart), "Tonii.JQueryWebParts.Resources.js.jquery-1.4.2.min.js"));

            HtmlGenericControl jQueryUIInclude = new HtmlGenericControl("script");
            jQueryUIInclude.Attributes.Add("type", "text/javascript");
            jQueryUIInclude.Attributes.Add("src", Page.ClientScript.GetWebResourceUrl(
                typeof(JQueryTabsWebPart), "Tonii.JQueryWebParts.Resources.js.jquery-ui-1.8.2.custom.min.js"));

            HtmlGenericControl jQueryCookieInclude = new HtmlGenericControl("script");
            jQueryCookieInclude.Attributes.Add("type", "text/javascript");
            jQueryCookieInclude.Attributes.Add("src", Page.ClientScript.GetWebResourceUrl(
                typeof(JQueryTabsWebPart), "Tonii.JQueryWebParts.Resources.js.jquery.cookie.js"));

            // include references to script resources 
            this.Page.Header.Controls.Add(jQueryInclude);
            this.Page.Header.Controls.Add(jQueryUIInclude);
            this.Page.Header.Controls.Add(jQueryCookieInclude);
        }

        protected void IncludeDefaultThemeCSS()
        {
            HtmlLink jQueryUICssInclude = new HtmlLink();
            jQueryUICssInclude.Href = Page.ClientScript.GetWebResourceUrl(
                typeof(JQueryTabsWebPart), "Tonii.JQueryWebParts.Resources.themes.smoothness.jquery-ui-1.8.2.custom.css");
            jQueryUICssInclude.Attributes["rel"] = "stylesheet";
            jQueryUICssInclude.Attributes["type"] = "text/css";
            jQueryUICssInclude.Attributes["media"] = "all";
            
            // include references to default theme (smoothness)
            this.Page.Header.Controls.Add(jQueryUICssInclude);
        }
        
        protected void IncludeHeaderScripts()
        {
            if (IncludeJQueryLibraries)
            {
                IncludeJQueryLibrariesScripts();
            }

            if (UseDefaultTheme)
            {
                IncludeDefaultThemeCSS();
            }

            HtmlGenericControl include = new HtmlGenericControl("script");
            include.Attributes.Add("type", "text/javascript");
            include.InnerHtml = string.Format(CultureInfo.InvariantCulture, "$(function() {{var wpTabs=$(\"#{0}\");wpTabs.tabs({{{1}}});", TabsId, TabsConstructorTemplate);
            //include.InnerHtml = string.Format(CultureInfo.InvariantCulture, "$(function() {{var wpTabs=$(\"#{0}\");wpTabs.tabs();", TabsId);
            
            StringBuilder jsTabsMap = new StringBuilder("var wppt = {");
            int i = 0;
            foreach (KeyValuePair<string, string> tab in WebPartsPerTab.Keys)
            {
                string tabId = tab.Key;
                string jsArray = ListToJSArray(WebPartsPerTab[tab]);
                jsTabsMap.AppendFormat("\"{0}-{1}\":{2}", this.TabsId, tabId, jsArray);
                if(i != WebPartsPerTab.Keys.Count - 1)
                    jsTabsMap.Append(",");
                ++i;
            }
            jsTabsMap.Append("};");

            
            include.InnerHtml += jsTabsMap.ToString();
            include.InnerHtml += "$.each(wppt, function(k, v){";
            include.InnerHtml += "$.each(v, function(){";
            include.InnerHtml += "var wp = $(\"div[WebPartID='\" + this + \"']\").parent().parent().parent().parent();";
            include.InnerHtml += "wp.find(\"script\").remove();";   
            include.InnerHtml += "wp.appendTo(\"#\" + k);";
            include.InnerHtml += "});";
            include.InnerHtml += "});";
            include.InnerHtml += "wpTabs.css('display', 'block');";
            include.InnerHtml += "});";
    
            this.Page.Header.Controls.Add(include);
        }

        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);
            IncludeHeaderScripts();
        }

        protected override void Render(HtmlTextWriter writer)
        {
            writer.AddAttribute(HtmlTextWriterAttribute.Id, TabsId);
            //writer.AddStyleAttribute(HtmlTextWriterStyle.Display, "none");
            writer.RenderBeginTag(HtmlTextWriterTag.Div);
            writer.RenderBeginTag(HtmlTextWriterTag.Ul);
            if (this.WebPartManager.DisplayMode != WebPartManager.BrowseDisplayMode)
            {
                writer.RenderBeginTag(HtmlTextWriterTag.Li);
                btnAddTab.RenderControl(writer);
                writer.RenderEndTag();
            }

            foreach (KeyValuePair<string, string> tab in WebPartsPerTab.Keys)
            {
                string tabId = tab.Key;
                string title = tab.Value;
                writer.RenderBeginTag(HtmlTextWriterTag.Li);
                writer.AddAttribute(HtmlTextWriterAttribute.Href, string.Format(CultureInfo.InvariantCulture, "#{0}-{1}", TabsId, tabId));
                writer.RenderBeginTag(HtmlTextWriterTag.A);
                writer.WriteEncodedText(title);
                writer.RenderEndTag();
                writer.AddStyleAttribute(HtmlTextWriterStyle.Padding, "5px");
                writer.RenderBeginTag(HtmlTextWriterTag.Span);
                deleteButtons[tabId].RenderControl(writer);
                writer.RenderEndTag();
                writer.RenderEndTag();
            }
            writer.RenderEndTag();
            foreach (KeyValuePair<string, string> tab in WebPartsPerTab.Keys)
            {
                string tabId = tab.Key;
         
                writer.AddAttribute(HtmlTextWriterAttribute.Id, string.Format(CultureInfo.InvariantCulture, "{0}-{1}", TabsId, tabId));
                writer.RenderBeginTag(HtmlTextWriterTag.Div);
                writer.RenderEndTag();
                
            }
            writer.RenderEndTag();

            // couldn't find another way to adjust content to tab size in IE
            writer.WriteLine("<!--[if IE]>");
            writer.AddAttribute(HtmlTextWriterAttribute.Type, "text/css");
            writer.RenderBeginTag(HtmlTextWriterTag.Style);
            writer.WriteLine(".ui-tabs-panel{float:left;}");
            writer.RenderEndTag();
            writer.WriteLine("<![endif]-->");
        }

        protected virtual void OnTabAdded(TabEventArgs e)
        {
            if (TabAdded != null)
            {
                TabAdded(this, e);
            }
        }

        protected virtual void OnTabDeleted(TabEventArgs e)
        {
            if (TabDeleted != null)
            {
                TabDeleted(this, e);
            }
        }
        #endregion

        #region EventHandlers
        void btnAddTab_Click(object sender, ImageClickEventArgs e)
        {
            string newTabId = Guid.NewGuid().ToString();
            WebPartsPerTab.Add(new KeyValuePair<string, string>(newTabId, "..."), new List<string>());
            this.SetPersonalizationDirty();
            AddTabDeleteButton(newTabId);
            OnTabAdded(new TabEventArgs(newTabId, "..."));
        }

        void btnDelete_Command(object sender, CommandEventArgs e)
        {
            string tabId = (string)e.CommandArgument;
            KeyValuePair<string, string> tab = FindTabById(tabId).Value;
            WebPartsPerTab.Remove(tab);
            this.SetPersonalizationDirty();
            deleteButtons.Remove(tabId);
            this.Controls.Remove(FindControl(tabId));
            OnTabDeleted(new TabEventArgs(tabId, ""));
        }

        void JQueryTabsWebPart_PreRender(object sender, EventArgs e)
        {
            SetEditModeControlsVisibility();
        }
        #endregion
    }
}
