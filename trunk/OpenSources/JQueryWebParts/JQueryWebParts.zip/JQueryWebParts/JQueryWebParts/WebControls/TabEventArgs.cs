﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tonii.JQueryWebParts.WebControls
{
    public class TabEventArgs : EventArgs
    {
        private string tabId;
        private string tabTitle;

        public string TabId { get { return this.tabId; } set { this.tabId = value;} }
        public string TabTitle { get { return this.tabTitle; } set { this.tabTitle = value; } }
        
        public TabEventArgs(string tabId, string tabTitle)
        {
            this.TabId = tabId;
            this.TabTitle = tabTitle;
        }
    }
}
