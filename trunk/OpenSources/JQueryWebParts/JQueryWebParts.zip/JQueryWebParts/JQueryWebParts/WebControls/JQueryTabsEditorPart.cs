using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.WebControls;
using System.Web.UI;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Utilities;
using System.Web.UI.HtmlControls;


namespace Tonii.JQueryWebParts.WebControls
{
    public class JQueryTabsEditorPart : EditorPart
    {
        #region Constants
        private const string DottedLineHtml = "<div style='width:100%' class='UserDottedLine'></div>";
        #endregion

        #region Fields
        private ListBox lbxWebparts;
        private ImageButton ibtAddWebParts;
        private ImageButton ibtDelWebParts;
        private CheckBox cbxUseDefaultTheme;
        private CheckBox cbxIncludeJQuery;
        private CheckBox cbxRememberLastTab;
        private TextBox txtTabConstructorTemplate;
        private Panel panTabsConfig;

        private Dictionary<RadioButton, KeyValuePair<TextBox, CheckBoxList>> tabsWebPartsList = new Dictionary<RadioButton, KeyValuePair<TextBox, CheckBoxList>>();

        private string addWebPartsButtonText = "Add";
        private string delWebPartsButtonText = "Remove";

        #endregion

        #region Constructors
        public JQueryTabsEditorPart()
        {
            LoadResources();
        }
        #endregion

        #region Static Methods
        private static List<string> GetWebPartsIdsInList(CheckBoxList cblWebParts)
        {
            List<string> selectedWebParts = new List<string>();
            foreach (ListItem li in cblWebParts.Items)
            {
                selectedWebParts.Add(li.Value);
            }
            return selectedWebParts;
        }

        private static List<string> GetSelectedWebPartsIdsInList(CheckBoxList cblWebParts)
        {
            List<string> selectedWebParts = new List<string>();
            foreach (ListItem li in cblWebParts.Items)
            {
                if (li.Selected)
                {
                    selectedWebParts.Add(li.Value);
                }
            }
            return selectedWebParts;
        }

        #endregion

        #region Methods
        protected override void OnInit(EventArgs e)
        {
            EnsureChildControls(); // early to ensure viewstate will be restored for dynamic controls
            base.OnInit(e);
            this.PreRender += new EventHandler(JQueryTabsEditorPart_PreRender);
        }

        void JQueryTabsEditorPart_PreRender(object sender, EventArgs e)
        {
            // we have to do this on every postback because a user may remove a webpart from
            // the page while the editorpart is shown.
            FillWebPartsList();

            // include default CSS
            HtmlGenericControl styles = new HtmlGenericControl("style");
            styles.Attributes["type"] = "text/css";
            styles.InnerHtml =
                ".ep-tab-webparts" +
                "{"             +
                "padding:5px 10px 5px 20;" + 
                "}"             +
                ".ep-tab-titlebox" + 
                "{"                +
                "border:1px solid black;background-color:white"       +
                "}";
            
            this.Page.Header.Controls.Add(styles);
        }

        private void LoadResources()
        {
            //addWebPartsButtonText = SPUtility.GetLocalizedString("$Resources:EditorPart_JQueryTabs_AddWebPartsButton", "JQueryWebParts", SPContext.Current.Web.Language);
            //delWebPartsButtonText = SPUtility.GetLocalizedString("$Resources:EditorPart_JQueryTabs_DelWebPartsButton", "JQueryWebParts", SPContext.Current.Web.Language);
        }

        protected override void CreateChildControls()
        {
            //this.CssClass = "jquerytabseditorpart";
            this.ChromeType = PartChromeType.None;
            base.CreateChildControls();
            EditorPartPanel editorPanel = new EditorPartPanel();
            editorPanel.Title = "Tabs configuration";
            //editorPanel.CssClass = "ms-ToolPartSpacing";
            this.Controls.Add(editorPanel);

            // include JQuery Property
            Panel includeJQueryPanel = new Panel();
            includeJQueryPanel.Controls.Add(new LiteralControl("<div class='UserSectionHead'><span>"));

            this.cbxIncludeJQuery = new CheckBox();
            this.cbxIncludeJQuery.Text = "Include JQuery";
            includeJQueryPanel.Controls.Add(cbxIncludeJQuery);
            
            includeJQueryPanel.Controls.Add(new LiteralControl("</span></div>"));
            includeJQueryPanel.Controls.Add(new LiteralControl(DottedLineHtml));
            editorPanel.ControlPanel.Controls.Add(includeJQueryPanel);


            // Use Default Theme property
            Panel useDefaultThemePanel = new Panel();
            useDefaultThemePanel.Controls.Add(new LiteralControl("<div class='UserSectionHead'><span>"));
            
            this.cbxUseDefaultTheme = new CheckBox();
            this.cbxUseDefaultTheme.CssClass = "UserInput";
            this.cbxUseDefaultTheme.Text = "Use default theme (smoothness)";
            useDefaultThemePanel.Controls.Add(cbxUseDefaultTheme);

            useDefaultThemePanel.Controls.Add(new LiteralControl("</span></div>"));
            useDefaultThemePanel.Controls.Add(new LiteralControl(DottedLineHtml));
            editorPanel.ControlPanel.Controls.Add(useDefaultThemePanel);

            // Use Default Theme property
            Panel rememberTabPanel = new Panel();
            rememberTabPanel.Controls.Add(new LiteralControl("<div class='UserSectionHead'><span>"));

            this.cbxRememberLastTab = new CheckBox();
            this.cbxRememberLastTab.CssClass = "UserInput";
            this.cbxRememberLastTab.Text = "Remember user's last Tab";
            this.cbxRememberLastTab.AutoPostBack = true;
            this.cbxRememberLastTab.CheckedChanged += new EventHandler(cbxRememberLastTab_CheckedChanged);
            rememberTabPanel.Controls.Add(cbxRememberLastTab);

            rememberTabPanel.Controls.Add(new LiteralControl("</span></div>"));
            rememberTabPanel.Controls.Add(new LiteralControl(DottedLineHtml));
            editorPanel.ControlPanel.Controls.Add(rememberTabPanel);

            // Tabs constructor property
            Panel tabsConstructorPanel = new Panel();
            tabsConstructorPanel.Controls.Add(new LiteralControl("<div class='UserSectionHead'><span>Tab constructor"));
            

            this.txtTabConstructorTemplate = new TextBox();
            this.txtTabConstructorTemplate.Width = Unit.Percentage(100);
            this.txtTabConstructorTemplate.TextMode = TextBoxMode.MultiLine;
            tabsConstructorPanel.Controls.Add(this.txtTabConstructorTemplate);

            tabsConstructorPanel.Controls.Add(new LiteralControl("</span></div>"));
            tabsConstructorPanel.Controls.Add(new LiteralControl(DottedLineHtml));
            editorPanel.ControlPanel.Controls.Add(tabsConstructorPanel);


            
            editorPanel.ControlPanel.Controls.Add(new LiteralControl("<div class='UserSectionHead'>Tabs & WebParts</div>"));
            editorPanel.ControlPanel.Controls.Add(new LiteralControl("<div class='UserSectionBody'><div class='UserControlsGroup'><nobr>"));
            
            lbxWebparts = new ListBox();
            lbxWebparts.CssClass = "UserInput";
            lbxWebparts.SelectionMode = ListSelectionMode.Multiple;
            lbxWebparts.Width = Unit.Percentage(100);
            lbxWebparts.Rows = 10;

            ibtAddWebParts = new ImageButton();
            ibtAddWebParts.Click += new ImageClickEventHandler(btnAddWebParts_Click);
            ibtAddWebParts.ImageUrl = Page.ClientScript.GetWebResourceUrl(typeof(JQueryTabsEditorPart), "Tonii.JQueryWebParts.Resources.img.addwebparts.png");
            
            ibtDelWebParts = new ImageButton();
            ibtDelWebParts.Click += new ImageClickEventHandler(btnDelWebParts_Click);
            ibtDelWebParts.ImageUrl = Page.ClientScript.GetWebResourceUrl(typeof(JQueryTabsEditorPart), "Tonii.JQueryWebParts.Resources.img.delwebparts.png");

            editorPanel.ControlPanel.Controls.Add(lbxWebparts);
            editorPanel.ControlPanel.Controls.Add(new LiteralControl("<div style='padding:10px;text-align:center;margin:auto;'>"));
            editorPanel.ControlPanel.Controls.Add(ibtAddWebParts);
            editorPanel.ControlPanel.Controls.Add(ibtDelWebParts);
            editorPanel.ControlPanel.Controls.Add(new LiteralControl("</div>"));

            panTabsConfig = new Panel();
            editorPanel.ControlPanel.Controls.Add(panTabsConfig);

            
            

            editorPanel.ControlPanel.Controls.Add(new LiteralControl("</div></div></nobr>"));
            CreateDynamicControls();
        }

        protected void RemoveSelectedWebParts()
        {
            foreach (KeyValuePair<TextBox, CheckBoxList> kvp in this.tabsWebPartsList.Values)
            {
                CheckBoxList cblWebParts = kvp.Value;
                List<string> webPartIds = GetSelectedWebPartsIdsInList(cblWebParts);

                foreach (string wpId in webPartIds)
                {
                    RemoveWebPartFromTab(wpId, cblWebParts);
                }
            }
        }

        protected void RemoveWebPartFromTab(string wpId, CheckBoxList cblTabWebParts)
        {
            ListItem li = cblTabWebParts.Items.FindByValue(wpId);
            lbxWebparts.Items.Add(new ListItem(li.Text, li.Value));
            cblTabWebParts.Items.Remove(li);
        }

        protected void RemoveWebPartsFromTab(CheckBoxList cblTabWebParts)
        {
            for(int i = 0; i < cblTabWebParts.Items.Count; ++i)
            {
                ListItem li = cblTabWebParts.Items[i];
                lbxWebparts.Items.Add(new ListItem(li.Text, li.Value));
                cblTabWebParts.Items.Remove(li);
            }
        }

        protected void FillWebPartsList()
        {
            lbxWebparts.Items.Clear();
            foreach (WebPart wp in this.WebPartManager.WebParts)
            {
                if (wp.ID == WebPartToEdit.ID)
                    continue;
                string wpId = wp.ID.Remove(0, 2).Replace("_", "-");
                bool found = false;
                foreach (KeyValuePair<TextBox, CheckBoxList> kvp in this.tabsWebPartsList.Values)
                {
                    
                    CheckBoxList cblWebParts = kvp.Value;
                    if (cblWebParts.Items.FindByValue(wpId) != null)
                    {
                        found = true;
                        break;
                    }
                }
                if (!found)
                    lbxWebparts.Items.Add(new ListItem(wp.Title, wpId));
            }
        }

        private List<ListItem> GetSelectedWebParts()
        {
            List<ListItem> items = new List<ListItem>();
            foreach (ListItem li in lbxWebparts.Items)
            {
                if (li.Selected)
                    items.Add(li);
            }
            return items;
        }

        private RadioButton GetSelectedTabRadio()
        {            
            foreach (RadioButton rbt in tabsWebPartsList.Keys)
            {
                if (rbt.Checked)
                {
                    return rbt;
                }
            }
            return null;
        }


        protected void CreateDynamicControls()
        {
            JQueryTabsWebPart wp = (JQueryTabsWebPart)this.WebPartToEdit;
            wp.TabAdded += new EventHandler<TabEventArgs>(wp_TabAdded);
            wp.TabDeleted += new EventHandler<TabEventArgs>(wp_TabDeleted);
            foreach (KeyValuePair<string, string> tab in wp.WebPartsPerTab.Keys)
            {
                AddTab(tab.Key, tab.Value);
            }
        }

        private void DeleteTab(string tabId)
        {
            Panel p = (Panel)this.FindControl(tabId);
            RadioButton rbTab = (RadioButton)p.Controls[0];
            KeyValuePair<TextBox, CheckBoxList> tabData = tabsWebPartsList[rbTab];
            RemoveWebPartsFromTab(tabData.Value);
            tabsWebPartsList.Remove(rbTab);
            panTabsConfig.Controls.Remove(p);
        }

        private void AddTab(string tabId, string tabTitle)
        {
            RadioButton rbtTab = new RadioButton();
            rbtTab.ID = "rbt" + tabId;
            rbtTab.GroupName = "Tabs";
            TextBox txtTitle = new TextBox();
            txtTitle.CssClass = "ep-tab-titlebox";
            CheckBoxList cblWebParts = new CheckBoxList();
            cblWebParts.RepeatLayout = RepeatLayout.Flow;
            txtTitle.Text = tabTitle;
            Panel p = new Panel();
            p.ID = tabId;
            p.Controls.Add(rbtTab);
            p.Controls.Add(txtTitle);
            p.Controls.Add(new LiteralControl("<div class='ep-tab-webparts';>"));
            p.Controls.Add(cblWebParts);
            p.Controls.Add(new LiteralControl("</div>"));
            
            panTabsConfig.Controls.Add(p);
            tabsWebPartsList.Add(rbtTab, new KeyValuePair<TextBox, CheckBoxList>(txtTitle, cblWebParts));
        }

        public override bool ApplyChanges()
        {
            try
            {
                EnsureChildControls();
                JQueryTabsWebPart wp = (JQueryTabsWebPart)this.WebPartToEdit;

                wp.TabsConstructorTemplate = this.txtTabConstructorTemplate.Text;
                wp.UseDefaultTheme = this.cbxUseDefaultTheme.Checked;
                wp.IncludeJQueryLibraries = this.cbxIncludeJQuery.Checked;

                wp.WebPartsPerTab = new Dictionary<KeyValuePair<string, string>, List<string>>();
                foreach (RadioButton rbtTab in this.tabsWebPartsList.Keys)
                {
                    CheckBoxList cblWebParts = this.tabsWebPartsList[rbtTab].Value;
                    TextBox txtTitle = this.tabsWebPartsList[rbtTab].Key;


                    wp.WebPartsPerTab.Add(new KeyValuePair<string, string>(rbtTab.Parent.ID, txtTitle.Text), GetWebPartsIdsInList(cblWebParts));
                }
            }
            catch
            {
                return false;
            }
            return true;
        }

        public override void SyncChanges()
        {
            EnsureChildControls();

            JQueryTabsWebPart wp = (JQueryTabsWebPart)this.WebPartToEdit;

            this.txtTabConstructorTemplate.Text = wp.TabsConstructorTemplate;
            this.cbxUseDefaultTheme.Checked = wp.UseDefaultTheme;
            this.cbxIncludeJQuery.Checked = wp.IncludeJQueryLibraries;
            
            
            foreach(KeyValuePair<string, string> tab in wp.WebPartsPerTab.Keys)
            {
                RadioButton rbtTab = (RadioButton)(this.FindControl("rbt" + tab.Key));
                CheckBoxList cblWebParts = this.tabsWebPartsList[rbtTab].Value;
                cblWebParts.Items.Clear();
                foreach (string wpId in wp.WebPartsPerTab[tab])
                { 
                    string wpIdFixed = "g_" + wpId.Replace("-", "_");
                    WebPart w = this.WebPartManager.WebParts[wpIdFixed];
                    if (w == null) // the webpart does not exist anymore
                        continue;
                    cblWebParts.Items.Add(new ListItem(w.Title, wpId));
                }
            }
        }
        #endregion

        #region EventHandlers
        void wp_TabDeleted(object sender, TabEventArgs e)
        {
            DeleteTab(e.TabId);
        }

        void wp_TabAdded(object sender, TabEventArgs e)
        {
            AddTab(e.TabId, e.TabTitle);
        }

        void btnDelWebParts_Click(object sender, ImageClickEventArgs e)
        {
            RemoveSelectedWebParts();
        }

        void btnAddWebParts_Click(object sender, ImageClickEventArgs e)
        {
            List<ListItem> selectedWebParts = this.GetSelectedWebParts();
            if (selectedWebParts.Count == 0)
                return;

            RadioButton rbtChecked = GetSelectedTabRadio();
            if (rbtChecked == null)
                return;

            CheckBoxList cblWebParts = tabsWebPartsList[rbtChecked].Value;
            foreach (ListItem li in selectedWebParts)
            {
                cblWebParts.Items.Add(new ListItem(li.Text, li.Value));
                lbxWebparts.Items.Remove(li);
            }
        }

        void cbxRememberLastTab_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxRememberLastTab.Checked)
            {
                txtTabConstructorTemplate.Text = "cookie:{expires:5000}"; // cookie expires in 5000 days
            }
            else
            {
                txtTabConstructorTemplate.Text = "";
            }
        }

        #endregion
    }
}
