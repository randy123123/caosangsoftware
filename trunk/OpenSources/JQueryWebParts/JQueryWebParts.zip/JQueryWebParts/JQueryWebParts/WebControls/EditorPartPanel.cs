﻿/*  
 * Credits for the panel code goes to Colin :
 * http://blog.techardinal.com/2009/09/09/advanced-editor-parts--style-and-grace.aspx
 * 
 */
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.WebControls;
using System.Web.UI;
using Microsoft.SharePoint;

namespace Tonii.JQueryWebParts.WebControls
{
    public class EditorPartPanel : Panel
    {
        //Constant references to the +/- image files that SharePoint uses
        private const string cImageMinus = "_layouts/images/TPMin2.gif";
        private const string cImagePlus = "_layouts/images/TPMax2.gif";

        //The javascript that sets up controls according to whether the panel
        //should be expanded or collapsed
        public const string jsToggleVisibility =
        "<script type=\"text/javascript\">" +
         "function toggleVisibility(pan, img, lab) " +
          "{var panel = document.getElementById(pan); " +
           "var image = document.getElementById(img); " +
           "var label = document.getElementById(lab); " +
           "if(panel.style.display == \"block\" || panel.style.display == \"\") " +
               "{" +
                  "panel.style.display = \"none\";" +
                  "image.src = \"_layouts/images/TPMax2.gif\";" +
                  "image.title = \"Expand category: \" + label.innerText;" +
                  "label.title = \"Expand category: \" + label.innerText;" +
               "}" +
            "else " +
               "{" +
                 "panel.style.display = \"block\";" +
                 "image.src = \"_layouts/images/TPMin2.gif\";" +
                 "image.title = \"Collapse category: \" + label.innerText;" +
                 "label.title = \"Collapse category: \" + label.innerText;" +
                 "}" +
          "}" +
        "</script>";

        public Panel ControlPanel = new Panel();
        protected Panel TitlePanel = new Panel();
        private Label labTitle = new Label();
        private Image imgToggleVis = new Image();
        
        //This property sets the text of the labTitle control
        //which is used as the equivalent of the Category group      
        public string Title
        {
            get { return labTitle.Text; }
            set { labTitle.Text = value; }
        }



        //There might be occasions when you don't want the standard header
        //panel and so we use ChromeType to direct what is displayed
        private PartChromeType _ChromeType = PartChromeType.Default;

        public PartChromeType ChromeType
        {

            get { return _ChromeType; }

            set
            {

                _ChromeType = value;

                switch (_ChromeType)
                {

                    case PartChromeType.None:
                        {

                            TitlePanel.Visible = false;

                            break;

                        }

                    case PartChromeType.BorderOnly:
                        {

                            TitlePanel.Visible = true;

                            labTitle.Visible = false;

                            imgToggleVis.Visible = true;

                            break;

                        }

                    case PartChromeType.TitleOnly:
                        {

                            TitlePanel.Visible = true;

                            labTitle.Visible = true;

                            imgToggleVis.Visible = false;

                            break;

                        }

                    default:
                        {

                            TitlePanel.Visible = true;

                            labTitle.Visible = true;

                            imgToggleVis.Visible = true;

                            break;

                        }

                }

            }

        }



        //The initial stae of the property panel

        private Boolean _Expanded = true;

        public Boolean Expanded
        {

            get { return _Expanded; }

            set { _Expanded = value; }

        }



        //Overloaded constructors

        public EditorPartPanel()
        {

        }



        public EditorPartPanel(string Title)
        {

            this.Title = Title;

        }



        //Create and initialise all the required controls

        protected override void OnInit(EventArgs e)
        {

            base.OnInit(e);



            //Setup and configure the title panel with a label header

            //and an +/- image which toggles the visibility of the

            //control panel

            TitlePanel.CssClass = "UserSectionTitle";

            imgToggleVis.ImageAlign = ImageAlign.AbsMiddle;

            imgToggleVis.Attributes.Add("style", "cursor:'hand';");

            if (Expanded)
            {

                ControlPanel.Attributes.Add("style", "display:'block';");

                imgToggleVis.ImageUrl = cImageMinus;

                imgToggleVis.ToolTip = "Collapse category: " + this.Title;

            }

            else
            {

                ControlPanel.Attributes.Add("style", "display:'none';");

                imgToggleVis.ImageUrl = cImagePlus;

                imgToggleVis.ToolTip = "Expand category: " + this.Title;

            }

            labTitle.ToolTip = imgToggleVis.ToolTip;

            TitlePanel.Controls.Add(new LiteralControl("&nbsp"));

            TitlePanel.Controls.Add(imgToggleVis);

            TitlePanel.Controls.Add(new LiteralControl("&nbsp&nbsp&nbsp"));

            labTitle.Attributes.Add("style", "cursor:'hand';");

            TitlePanel.Controls.Add(labTitle);



            //Add the two inner panels to the Controls collection.  This needs to be done

            //before we attach the client script as we need to pass control ClientIDs

            Controls.Add(TitlePanel);

            Controls.Add(ControlPanel);



            //Register the client side script which configures controls according

            //to whether they panel is expanded or collapsed

            RegisterClientScript(Page, this.GetType().ToString() + "_ToggleVisibility",

                    jsToggleVisibility);



            //Build the javascript call using the ClientIDs of the controls we need to adjust

            string ClientToggleScript = string.Format("toggleVisibility('{0}','{1}','{2}')",

                                            ControlPanel.ClientID.ToString(),

                                            imgToggleVis.ClientID.ToString(),

                                            labTitle.ClientID.ToString());



            //Attach the client script calls to the +/- button and the label

            imgToggleVis.Attributes.Add("onclick", ClientToggleScript);

            labTitle.Attributes.Add("onclick", ClientToggleScript);



        }



        //Helper method to register the client script

        public static void RegisterClientScript(Page Page, string ScriptBlockName, string Script)
        {

            //We only need to register this secript when we are in Edit mode

            if ((WebPartManager.GetCurrentWebPartManager(Page).DisplayMode != WebPartManager.EditDisplayMode) ||

                (Script == string.Empty)) return;



            //Get a handle onto the page Client Script Manager

            ClientScriptManager ThisPageClientScriptManager = Page.ClientScript;

            Type PageType = Page.GetType();



            //Check to see if we have a script block to load and, if it is not already on the page, load it.

            if (!ThisPageClientScriptManager.IsClientScriptBlockRegistered(PageType, ScriptBlockName))

                Page.ClientScript.RegisterClientScriptBlock(PageType,

                      ScriptBlockName, Script, (!Script.StartsWith("<")));

        }

    }



}