﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Chaks.SharePoint.jQuery
{
    public class ImageCycle
    {
        public string Url { get; set; }

        public string AltText { get; set; }
    }
}
