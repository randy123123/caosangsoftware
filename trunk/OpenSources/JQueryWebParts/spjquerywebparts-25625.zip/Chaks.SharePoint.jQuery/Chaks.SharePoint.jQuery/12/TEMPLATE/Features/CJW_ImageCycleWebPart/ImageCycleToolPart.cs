﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using Microsoft.SharePoint.WebPartPages;
using System.Web.UI.WebControls;
using Microsoft.SharePoint;
using System.Web.UI.HtmlControls;

namespace Chaks.SharePoint.jQuery
{
    public class ImageCycleToolPart : ToolPart
    {
        private readonly string[] imageCycleEffects = new[] { "fade", "zoom", "wipe", "uncover", "blindX", "blindY", "blindZ", "fadeZoom", "curtainX", "curtainY", "growX", "growY", "turnLeft", "turnRight", "turnUp", "turnDown", "slideX", "slideY", "scrollVert", "scrollHorz", "scrollRight", "scrollLeft", "scrollUp", "scrollDown" };

        protected Label lblPicturesList=new Label();
        protected DropDownList ddlPicturesList=new DropDownList();
        
        protected Label lblTransition = new Label();
        protected DropDownList ddlTransition=new DropDownList();

        protected Label lblTimeout=new Label();
        protected TextBox txtTimeout = new TextBox();

        protected Label lblSpeed=new Label();
        protected TextBox txtSpeed = new TextBox();


        /// <summary>
        /// Initializes a new instance of the <see cref="ImageCycleToolPart"/> class.
        /// </summary>
        public ImageCycleToolPart()
        {
            Title = "jQuery Web Parts Options";
        }

        /// <summary>
        /// Gets the parent web part.
        /// </summary>
        /// <value>The parent web part.</value>
        protected ImageCycleWebPart ParentWebPart
        {
            get
            {
                return (ImageCycleWebPart)ParentToolPane.SelectedWebPart;
            }
        }

        /// <summary>
        /// Sends the tool part content to the specified HtmlTextWriter object, which writes the content to be rendered on the client.
        /// </summary>
        /// <param name="output">The HtmlTextWriter object that receives the tool part content.</param>
        protected override void RenderToolPart(HtmlTextWriter output)
        {
            AddPicturesControls(ref output);
        }
       

        /// <summary>
        /// Called by the ASP.NET page framework to notify server controls that use composition-based implementation to create any child controls they contain in preparation for posting back or rendering.
        /// </summary>
        protected override void CreateChildControls()
        {
            base.CreateChildControls();

            Controls.Add(lblPicturesList);
            Controls.Add(ddlPicturesList);

            Controls.Add(lblTransition);
            Controls.Add(ddlTransition);

            Controls.Add(lblTimeout);
            Controls.Add(txtTimeout);

            Controls.Add(lblSpeed);
            Controls.Add(txtSpeed);
        }

        /// <summary>
        /// Raises the <see cref="E:System.Web.UI.Control.PreRender"/> event.
        /// </summary>
        /// <param name="e">An <see cref="T:System.EventArgs"/> that contains the event data.</param>
        /// <exception cref="T:System.InvalidOperationException">
        /// The <see cref="T:System.Web.UI.WebControls.WebParts.EditorZoneBase"/> that contains the <see cref="T:System.Web.UI.WebControls.WebParts.EditorPart"/> control is null.
        /// </exception>
        protected override void OnPreRender(EventArgs e)
        {
            SPSite site = SPContext.GetContext(HttpContext.Current).Site;

            using (SPWeb web = site.OpenWeb())
            {

                ddlPicturesList.Items.Clear();
                ddlTransition.Items.Clear();

                foreach (SPList list in web.Lists)
                {
                    if (list.BaseTemplate == SPListTemplateType.PictureLibrary)
                    {
                        string listTitle = list.Title;
                        string listID = list.ID.ToString();

                        ListItem imgItem = new ListItem(listTitle, listID);
                        imgItem.Selected = listID == ParentWebPart.LibraryName;

                        ddlPicturesList.Items.Add(imgItem);
                    }
                }
            }

            foreach (string cycleEffect in imageCycleEffects)
            {
                ListItem effectItem = new ListItem(cycleEffect, cycleEffect);
                effectItem.Selected = cycleEffect == ParentWebPart.Transition;
                ddlTransition.Items.Add(effectItem);
            }

            txtTimeout.Text = !String.IsNullOrEmpty(ParentWebPart.Timeout) ? ParentWebPart.Timeout : "2000";

            txtSpeed.Text = !String.IsNullOrEmpty(ParentWebPart.Speed) ? ParentWebPart.Speed : "500";

            base.OnPreRender(e);
        }

        /// <summary>
        /// Called when the user clicks the OK or the Apply button in the tool pane.
        /// </summary>
        public override void ApplyChanges()
        {
            ParentWebPart.LibraryName = ddlPicturesList.SelectedValue;
            
            ParentWebPart.Transition = ddlTransition.SelectedValue;

            if (!String.IsNullOrEmpty(txtTimeout.Text))
            {
                ParentWebPart.Timeout = txtTimeout.Text;
            }

            if (!String.IsNullOrEmpty(txtSpeed.Text))
            {
                ParentWebPart.Speed = txtSpeed.Text;
            }

            base.ApplyChanges();
        }

        /// <summary>
        /// Adds the pictures controls.
        /// </summary>
        /// <param name="output">The output.</param>
        /// <returns></returns>
        private void AddPicturesControls(ref HtmlTextWriter output)
        {
            #region Pictures List

            output.Write("<br/>");
            output.Write("<div>");

            lblPicturesList.Text = "Pictures List";
            lblPicturesList.RenderControl(output);

            output.Write("<br/>");
            ddlPicturesList.RenderControl(output);

            output.Write("</div>");

            #endregion

            #region Transition Effect

            output.Write("<br/>");
            output.Write("<div>");

            lblTransition.Text = "Transition";
            lblTransition.RenderControl(output);

            output.Write("<br/>");
            ddlTransition.RenderControl(output);

            output.Write("</div>");

            #endregion

            #region Timeout

            output.Write("<br/>");
            output.Write("<div>");

            lblTimeout.Text = "Timeout";
            lblTimeout.RenderControl(output);
            
            output.Write("<br/>");
            txtTimeout.RenderControl(output);

            output.Write("</div>");

            #endregion

            #region Speed

            output.Write("<br/>");
            output.Write("<div>");

            lblSpeed.Text = "Speed";
            lblSpeed.RenderControl(output);

            output.Write("<br/>");
            txtSpeed.RenderControl(output);

            output.Write("</div>");

            #endregion

            return;
        }
    }
}
