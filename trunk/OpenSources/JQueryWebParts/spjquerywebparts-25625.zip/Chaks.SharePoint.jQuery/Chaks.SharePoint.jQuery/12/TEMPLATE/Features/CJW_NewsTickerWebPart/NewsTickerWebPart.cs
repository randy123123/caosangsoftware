using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Serialization;

using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.WebPartPages;
using System.Web.UI.HtmlControls;

namespace Chaks.SharePoint.jQuery
{
    public class NewsTickerWebPart : Microsoft.SharePoint.WebPartPages.WebPart
    {
        private UserControl newsTickerControl;

        private StringBuilder cycleScriptBuilder = new StringBuilder();

        #region Constructors

        public NewsTickerWebPart()
        {

        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the name of the library.
        /// </summary>
        /// <value>The name of the library.</value>
        public string LibraryName
        {
            get; set;
        }

        /// <summary>
        /// Gets or sets the height of the news ticker.
        /// </summary>
        /// <value>The height of the news ticker.</value>
        public string NewsTickerHeight
        {
            get; set;
        }

        #endregion

        #region Methods 

        protected override void OnPreRender(EventArgs e)
        {
            #region Build Script

            //cycleScriptBuilder.Append("<script type=\"text/javascript\">$(document).ready(function(){$('#news').newsticker();");

            cycleScriptBuilder.Append("<script type=\"text/javascript\">$(function(){$('#news').newsticker();");

            int nParsedInteger;
           
            if (!String.IsNullOrEmpty(NewsTickerHeight) && Int32.TryParse(NewsTickerHeight, out nParsedInteger))
            {
                cycleScriptBuilder.Append(String.Format("$('#news').equalHeights({0});", NewsTickerHeight));
            }
            else
            {
                cycleScriptBuilder.Append("$('#news').equalHeights(100);");
            }

            cycleScriptBuilder.Append("});</script>");

            #endregion
            
            if (LibraryName!=null)
            {
                #region Get Announcements

                List<Announcement> announcements = new List<Announcement>();

                SPSite site = SPContext.GetContext(HttpContext.Current).Site;

                using (SPWeb curWeb = site.OpenWeb())
                {

                    SPList lstAnnouncements = curWeb.Lists[new Guid(LibraryName)];

                    SPQuery camlQuery = new SPQuery();
                    camlQuery.ViewFields = "<FieldRef Name='Title' /><FieldRef Name='Body' />";
                    camlQuery.Query = "<OrderBy><FieldRef Name='Created' Ascending='True' /></OrderBy>";

                    SPListItemCollection lstAnnouncementsCollection = lstAnnouncements.GetItems(camlQuery);

                    foreach (SPListItem annItem in lstAnnouncementsCollection)
                    {
                        Announcement ann = new Announcement
                                               {
                                                   Title = annItem["Title"].ToString(),
                                                   Body = annItem["Body"].ToString()
                                               };

                        announcements.Add(ann);
                    }
                }

                #endregion

                #region Set Control Values

                Literal ltlNewsTickerScript = newsTickerControl.FindControl("ltlNewsTickerScript") as Literal;
                ltlNewsTickerScript.Text = cycleScriptBuilder.ToString();

                Repeater rptrAnnouncements = newsTickerControl.FindControl("rptrAnnouncements") as Repeater;
                rptrAnnouncements.DataSource = announcements;
                rptrAnnouncements.DataBind();

                #endregion
            }


            base.OnPreRender(e);
        }

        protected override void CreateChildControls()
        {
            base.CreateChildControls();

            newsTickerControl = Page.LoadControl("~/_controltemplates/Chaks.SharePoint.jQuery/NewsTickerControl.ascx") as UserControl;

            Controls.Add(newsTickerControl);
        }

        public override ToolPart[] GetToolParts()
        {
            ToolPart[] toolParts = new ToolPart[] { new WebPartToolPart(),new NewsTickerToolPart()};

            return toolParts;
        }

        #endregion
    }
}
