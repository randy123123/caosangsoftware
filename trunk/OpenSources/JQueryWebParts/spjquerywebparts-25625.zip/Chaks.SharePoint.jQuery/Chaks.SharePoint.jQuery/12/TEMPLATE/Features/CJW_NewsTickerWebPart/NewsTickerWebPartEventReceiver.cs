using System;
using System.Security.Permissions;
using System.Runtime.InteropServices;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Security;

namespace Chaks.SharePoint.jQuery
{
    [System.ComponentModel.Category("217B7983-A829-4405-9A72-57EB9AB6703B")] //Don't remove! This attribute is added by SPVisualDev to bind it to a WSS feature ID.
    public class NewsTickerWebPartEventReceiver : SPFeatureReceiver
    {
        /// <summary>
        /// Initializes a new instance of the Microsoft.SharePoint.SPFeatureReceiver class.
        /// </summary>
        public NewsTickerWebPartEventReceiver()
        {
        }

        /// <summary>
        /// TODO
        /// </summary>
        /// <param name="properties">
        /// A Microsoft.SharePoint.SPFeatureReceiverProperties object that represents properties of the event handler.
        /// </param>
        public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        {
        }

        /// <summary>
        /// TODO
        /// </summary>
        /// <param name="properties">
        /// A Microsoft.SharePoint.SPFeatureReceiverProperties object that represents properties of the event handler.
        /// </param>
        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
        }

        /// <summary>
        /// TODO
        /// </summary>
        /// <param name="properties">
        /// A Microsoft.SharePoint.SPFeatureReceiverProperties object that represents properties of the event handler.
        /// </param>
        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
            properties.RemoveWebPartFromGallery();
        }

        /// <summary>
        /// TODO
        /// </summary>
        /// <param name="properties">
        /// A Microsoft.SharePoint.SPFeatureReceiverProperties object that represents properties of the event handler.
        /// </param>
        public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        {
            properties.RemoveWebPartFromGallery();
        }
    }
}
