using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Serialization;

using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.WebPartPages;
using System.Web.UI.HtmlControls;

namespace Chaks.SharePoint.jQuery
{
    public class AccordionWebPart : Microsoft.SharePoint.WebPartPages.WebPart
    {
        private UserControl accordianControl;

        #region Constructors 
        
        public AccordionWebPart()
        {

        }

        #endregion

        #region Properties

        public string LibraryName
        {
            get; set;
        }

        #endregion

        #region Methods

        protected override void OnPreRender(EventArgs e)
        {
            //string selectedTheme = String.Format("/_layouts/jQueryThemes/{0}/ui.all.css",Theme);
            //HtmlGenericControl themeSelector = accordianControl.FindControl("themeSelector") as HtmlGenericControl;
            //themeSelector.Attributes.Add("href", selectedTheme);

            if (!String.IsNullOrEmpty(LibraryName))
            {
                List<Announcement> announcements = new List<Announcement>();

                SPSite site = SPContext.GetContext(HttpContext.Current).Site;

                using (SPWeb curWeb = site.OpenWeb())
                {

                    SPList lstAnnouncements = curWeb.Lists[new Guid(LibraryName)];

                    SPQuery camlQuery = new SPQuery();
                    camlQuery.ViewFields = "<FieldRef Name='Title' /><FieldRef Name='Body' />";
                    camlQuery.Query = "<OrderBy><FieldRef Name='Created' Ascending='True' /></OrderBy>";

                    SPListItemCollection lstAnnouncementsCollection = lstAnnouncements.GetItems(camlQuery);

                    foreach (SPListItem annItem in lstAnnouncementsCollection)
                    {
                        Announcement ann = new Announcement
                                               {
                                                   Title = annItem["Title"].ToString(),
                                                   Body = annItem["Body"].ToString()
                                               };

                        announcements.Add(ann);
                    }
                }

                Repeater rptrAnnouncements = accordianControl.FindControl("rptrAnnouncements") as Repeater;
                rptrAnnouncements.DataSource = announcements;
                rptrAnnouncements.DataBind();
                
            }


            base.OnPreRender(e);
        }

        protected override void CreateChildControls()
        {
            base.CreateChildControls();
            
            accordianControl = Page.LoadControl("~/_controltemplates/Chaks.SharePoint.jQuery/AccordionControl.ascx") as UserControl;
            
            Controls.Add(accordianControl);
        }

        public override ToolPart[] GetToolParts()
        {
            ToolPart[] toolParts = new ToolPart[] { new WebPartToolPart(),new AccordionToolPart()};

            return toolParts;
        }

        #endregion
    }
}
