using System;
using System.Globalization;
using System.Linq;
using System.Security.Permissions;
using System.Runtime.InteropServices;
using System.Xml;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.Security;

namespace Chaks.SharePoint.jQuery
{
    [System.ComponentModel.Category("4D1626E6-1E13-4483-A450-81D551B542A5")] //Don't remove! This attribute is added by SPVisualDev to bind it to a WSS feature ID.
    public class AccordionWebPartEventReceiver : SPFeatureReceiver
    {
        /// <summary>
        /// Initializes a new instance of the Microsoft.SharePoint.SPFeatureReceiver class.
        /// </summary>
        public AccordionWebPartEventReceiver()
        {
        }

        /// <summary>
        /// TODO
        /// </summary>
        /// <param name="properties">
        /// A Microsoft.SharePoint.SPFeatureReceiverProperties object that represents properties of the event handler.
        /// </param>
        public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        {
        }

        /// <summary>
        /// TODO
        /// </summary>
        /// <param name="properties">
        /// A Microsoft.SharePoint.SPFeatureReceiverProperties object that represents properties of the event handler.
        /// </param>
        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
        }

        /// <summary>
        /// TODO
        /// </summary>
        /// <param name="properties">
        /// A Microsoft.SharePoint.SPFeatureReceiverProperties object that represents properties of the event handler.
        /// </param>
        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
            properties.RemoveWebPartFromGallery();
        }

        /// <summary>
        /// TODO
        /// </summary>
        /// <param name="properties">
        /// A Microsoft.SharePoint.SPFeatureReceiverProperties object that represents properties of the event handler.
        /// </param>
        public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        {
            properties.RemoveWebPartFromGallery();
        }
    }
}
